<?php
$active_menu = "finance";
include "header.php";
require_once __DIR__ . "/../foundation.php";
require_once __DIR__ . "/../depositCollections.php";
oecrm_require_permission($conn, "bank_reconciliation", "view");
$companyId = oecrm_current_company_id($conn);
$accounts = oecrm_collection_bank_accounts($conn);
$rows = mysqli_query(
    $conn,
    "SELECT r.*,a.account_name FROM bank_reconciliation r JOIN account a ON a.account_id=r.account_id WHERE r.company_id=" .
        $companyId .
        " ORDER BY statement_date DESC"
);
$cash = mysqli_query(
    $conn,
    "SELECT period,SUM(inflow) inflow,SUM(outflow) outflow FROM (SELECT DATE_FORMAT(payment_date,'%Y-%m') period,SUM(amount-gateway_fee-bank_charge) inflow,0 outflow FROM finance_payments WHERE company_id=$companyId GROUP BY period UNION ALL SELECT DATE_FORMAT(expense_date,'%Y-%m'),0,SUM(amount) FROM finance_expenses WHERE company_id=$companyId GROUP BY DATE_FORMAT(expense_date,'%Y-%m'))x GROUP BY period ORDER BY period DESC LIMIT 12"
);
?><div id="page-wrapper" class="compact-admin-page">
  <div class="foundation-titlebar"><a href="finance.php"><i class="fa fa-arrow-left"></i> Finance</a>
    <h2>Bank Reconciliation & Cash Flow</h2>
  </div>
  <?php if (!empty($_SESSION['reconciliation_error'])): ?><div class="alert alert-danger"><?php echo oecrm_h($_SESSION['reconciliation_error']); unset($_SESSION['reconciliation_error']); ?></div><?php endif; ?>
  <div class="asset-layout">
    <section>
      <div class="panel panel-default">
        <div class="panel-heading">Cash Flow</div>
        <div class="panel-body table-responsive">
          <table class="table foundation-table">
            <thead>
              <tr>
                <th>Period</th>
                <th>Inflow</th>
                <th>Outflow</th>
                <th>Net Flow</th>
              </tr>
            </thead>
            <tbody><?php while (
                    $r = mysqli_fetch_assoc($cash)
                ): ?><tr>
                                <td><?php echo oecrm_h(
                    $r["period"]
                ); ?></td>
                                <td><?php echo number_format(
                    $r["inflow"],
                    2
                ); ?></td>
                                <td><?php echo number_format(
                    $r["outflow"],
                    2
                ); ?></td>
                                <td><?php echo number_format(
                    $r["inflow"] - $r["outflow"],
                    2
                ); ?></td>
              </tr><?php endwhile; ?></tbody>
          </table>
        </div>
      </div>
      <div class="panel panel-default">
        <div class="panel-heading">Reconciliation History</div>
        <div class="panel-body table-responsive">
          <table class="table foundation-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Account</th>
                <th>Statement</th>
                <th>Book</th>
                <th>Difference</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody><?php while (
    $r = mysqli_fetch_assoc($rows)
): ?><tr>
                <td><?php echo $r["statement_date"]; ?></td>
                <td><?php echo oecrm_h(
    $r["account_name"]
); ?></td>
                <td><?php echo number_format(
    $r["statement_balance"],
    2
); ?></td>
                <td><?php echo number_format(
    $r["book_balance"],
    2
); ?></td>
                <td><?php echo number_format(
    $r["difference_amount"],
    2
); ?></td>
                <td><?php echo ucfirst(
    $r["status"]
); ?></td>
              </tr><?php endwhile; ?></tbody>
          </table>
        </div>
      </div>
    </section>
    <aside>
      <div class="panel panel-default">
        <div class="panel-heading">New Reconciliation</div>
        <div class="panel-body">
          <form method="post" action="reconciliationAction.php"><?php echo oecrm_csrf_field(); ?><select
              class="form-control" name="account_id" required data-search-placeholder="Search bank name..." data-oecrm-dropdown="viewport">
              <option value="">Select account</option><?php while (
    $a = mysqli_fetch_assoc($accounts)
): ?><option value="bank:<?php echo (int) $a["bank_id"]; ?>" data-balance="<?php echo oecrm_h($a["current_balance"]); ?>"><?php echo oecrm_h(
    $a["account_name"] . " - Balance: " . number_format((float) $a["current_balance"], 2)
); ?></option><?php endwhile; ?>
            </select><br><input class="form-control" type="date" name="statement_date" value="<?php echo date(
    "Y-m-d"
); ?>" required><br><input class="form-control" type="number" step=".01" name="statement_balance"
              placeholder="Statement balance" required><br><textarea class="form-control" name="notes"
              placeholder="Notes"></textarea><br><button class="btn btn-primary btn-block">Save Reconciliation</button>
          </form>
        </div>
      </div>
    </aside>
  </div>
</div><?php include "footer.php"; ?>